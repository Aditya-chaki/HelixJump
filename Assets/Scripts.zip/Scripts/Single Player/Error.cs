﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Error : MonoBehaviour {

	public void OnCollisionEnter(Collision other)
	{
		if (other.gameObject.CompareTag("Player1"))
		{
			// Decrease the score by 1 . create function in gameplaymanager
		  

		}
	}
}