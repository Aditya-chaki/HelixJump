using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public float xMargin = 1f;
    public float yMargin = 1f;
    public float xSmooth = 8f;
    public float ySmooth = 8f;

    [SerializeField] private Transform m_Ball; // Drag and drop the player in the Inspector

    private bool CheckXMargin()
    {
        return Mathf.Abs(transform.position.x - m_Ball.position.x) > xMargin;
    }

    private bool CheckYMargin()
    {
        return Mathf.Abs(transform.position.y - m_Ball.position.y) > yMargin;
    }

    private void Update()
    {
        TrackBall();
    }

    private void TrackBall()
    {
        float targetX = transform.position.x;
        float targetY = transform.position.y;

        if (CheckXMargin())
        {
            targetX = Mathf.Lerp(transform.position.x, m_Ball.position.x, xSmooth * Time.deltaTime);
        }

        if (CheckYMargin())
        {
            targetY = Mathf.Lerp(transform.position.y, m_Ball.position.y, ySmooth * Time.deltaTime);
        }

        transform.position = new Vector3(targetX, targetY, transform.position.z);
    }
}