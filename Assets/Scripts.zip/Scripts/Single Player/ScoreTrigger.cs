﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreTrigger : MonoBehaviour {


	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("Player1"))
		{
			//score
			GameplayManager.Instance.IncrementPlayer1Score();
			
		}
		if (other.CompareTag("Player2"))
		{
			//score
			GameplayManager.Instance.IncrementPlayer2Score();
			
		}
	}


}
