using System.Collections.Generic;
using Fusion;
using UnityEngine;
using System.Collections;
using System.Linq;

public class GameManager : NetworkBehaviour
{
    [SerializeField] private GameObject Ring1, Ring2, Ring3, Ring4, Ring5;
    [SerializeField] private GameObject Ball;
    [SerializeField] private Transform ReferenceCylinder;
    [Networked] public string PlayerId { get; set; }

    private List<GameObject> Rings = new List<GameObject>();
    private float _newPosition = -10f;

    public override void Spawned()
    {
        Rings.AddRange(new GameObject[] { Ring1, Ring2, Ring3, Ring4, Ring5 });

        if (Object.HasStateAuthority)
        {
            if (ReferenceCylinder == null)
            {
                Debug.LogError($"[GameManager] ReferenceCylinder is not set for {PlayerId}!");
                return;
            }

            StartCoroutine(SetInitialPositionsAfterDelay());
        }
    }

    private IEnumerator SetInitialPositionsAfterDelay()
    {
        Debug.Log("First rings instantiated");
        yield return new WaitForSeconds(0.5f);

        if (Rings.Any(r => r == null))
        {
            Debug.LogError($"[GameManager] Some rings are not assigned for {PlayerId}!");
            yield break;
        }

        float cylinderX = ReferenceCylinder.position.x;
        float cylinderZ = ReferenceCylinder.position.z;

        Vector3 pos1 = new Vector3(cylinderX, 5f, cylinderZ);
        Vector3 pos2 = new Vector3(cylinderX, 2f, cylinderZ);
        Vector3 pos3 = new Vector3(cylinderX, -1f, cylinderZ);
        Vector3 pos4 = new Vector3(cylinderX, -4f, cylinderZ);
        Vector3 pos5 = new Vector3(cylinderX, -7f, cylinderZ);
       

        // Call RPC without PlayerId
        RPC_SetInitialRingPositions(pos1, pos2, pos3, pos4, pos5);

        _newPosition = -10f;
    }

    [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
    public void RPC_SetInitialRingPositions(Vector3 pos1, Vector3 pos2, Vector3 pos3, Vector3 pos4, Vector3 pos5)
    {
        if (Ring1 == null) Debug.LogError($"[GameManager] Ring1 null for PlayerId={PlayerId}");
        Ring1.transform.position = pos1;
        Ring2.transform.position = pos2;
        Ring3.transform.position = pos3;
        Ring4.transform.position = pos4;
        Ring5.transform.position = pos5;
        Debug.Log($"[GameManager] Positions set for PlayerId={PlayerId}");
    }

    // Rest of the code remains unchanged
    public override void FixedUpdateNetwork()
    {
        if (Object.HasStateAuthority)
        {
            if (Ball != null)
            {
                float ballY = Ball.transform.position.y;
                for (int i = 0; i < Rings.Count; i++)
                {
                    GameObject ring = Rings[i];
                    if (ring != null && ring.transform.position.y > ballY + 3f)
                    {
                        Vector3 newPos = new Vector3(ReferenceCylinder.position.x, _newPosition, ReferenceCylinder.position.z);
                        RPC_SetRingPosition(PlayerId, i, newPos);
                        _newPosition -= 3f;
                    }
                }
            }
            else
            {
                Debug.LogError($"[GameManager] BALL reference is not set for {PlayerId}!");
            }
        }
    }

    [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
    public void RPC_SetRingPosition(string targetPlayerId, int index, Vector3 position)
    {
        if (PlayerId == targetPlayerId && index >= 0 && index < Rings.Count && Rings[index] != null)
        {
            Rings[index].transform.position = position;
        }
    }
}