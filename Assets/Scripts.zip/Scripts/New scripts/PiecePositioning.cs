using System.Collections.Generic;
using UnityEngine;
using Fusion;

public class PiecePositioning : NetworkBehaviour
{
    public GameObject SafePiece;
    public GameObject UnsafePiece;
    List<int> Angles = new List<int>();
    List<GameObject> Pieces = new List<GameObject>();

    private NetworkObject networkObject;

    [Networked] public int PieceSeed { get; set; }

    public override void Spawned()
    {
        if (Object.HasStateAuthority)
        {
            PieceSeed = Random.Range(0, int.MaxValue);
        }
    }

    void Start()
    {
        networkObject = GetComponentInParent<NetworkObject>();
        Angles.AddRange(new int[] { 0, 45, 90, 135, 180, 225, 270, 315 });

        var oldState = Random.state;
        Random.InitState(PieceSeed);
        PieceCreation();
        Random.state = oldState;
    }

    private void PieceCreation()
    {
        RandomAngulation(Angles);

        int NumberOfSafePieces = Random.Range(3, 5);
        for (int i = 0; i < NumberOfSafePieces; i++)
        {
            Pieces.Add(Instantiate(SafePiece, transform.position, Quaternion.Euler(0, Angles[i], 0)));
            Pieces[i].transform.parent = gameObject.transform;
        }

        int NumberOfUnsafePieces = Random.Range(2, 4);
        for (int j = NumberOfSafePieces; j < NumberOfSafePieces + NumberOfUnsafePieces; j++)
        {
            Pieces.Add(Instantiate(UnsafePiece, transform.position, Quaternion.Euler(0, Angles[j], 0)));
            Pieces[j].transform.parent = gameObject.transform;
        }
    }

    private void RandomAngulation(List<int> Angles)
    {
        for (int i = 0; i < Angles.Count; i++)
        {
            int t = Angles[i];
            int r = Random.Range(0, Angles.Count - i);
            Angles[i] = Angles[i + r];
            Angles[i + r] = t;
        }
    }

    void RandomPositioning(List<GameObject> Pieces, List<int> Angles)
    {
        RandomAngulation(Angles);
        for (int i = 0; i < Pieces.Count; i++)
        {
            Pieces[i].transform.rotation = Quaternion.Euler(0, Angles[i], 0);
        }
    }

    [Rpc(RpcSources.InputAuthority, RpcTargets.All)]
    public void RPC_RandomPositioning(int seed)
    {
        var oldState = Random.state;
        Random.InitState(seed);
        RandomPositioning(Pieces, Angles);
        Random.state = oldState;
    }

private void OnTriggerEnter(Collider other)
    {
        if (other.transform.parent == transform.parent && other.name == "BALL")
        {
            if (networkObject != null && networkObject.HasInputAuthority)
            {
                int seed = Random.Range(0, int.MaxValue);
                RPC_RandomPositioning(seed);
            }
        }
    }
}