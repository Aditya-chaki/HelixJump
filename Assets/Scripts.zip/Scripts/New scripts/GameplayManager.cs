using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Fusion;
using System.Linq;
using Game.Utility;

public class GameplayManager : Singleton<GameplayManager>
{
    public int player1Score = 0;
    public int player2Score = 0;
    public int scoreToWin = 5;
    public TextMeshProUGUI scoreText;
    public GameObject scoreboardPanel;
    private bool isGameEnded = false;
    private bool isOnePlayerMode = false;
    private bool isGameStarted = false;
    public Transform player1Pos, player2Pos;
    public NetworkObject playerPrefab;

    public string LocalPlayerId { get; private set; }

    private HelixTowerRotation player1Helix;
    private HelixTowerRotation player2Helix;

    public override void Awake()
    {
        base.Awake();
        DontDestroyObjectOnLoad = true;

        if (player1Pos == null)
        {
            GameObject player1Spawn = new GameObject("Player1Spawn");
            player1Spawn.transform.position = new Vector3(-10, 0, 0);
            player1Pos = player1Spawn.transform;
            Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Created Player1Spawn at (-10, 0, 0)");
        }

        if (player2Pos == null)
        {
            GameObject player2Spawn = new GameObject("Player2Spawn");
            player2Spawn.transform.position = new Vector3(10, 0, 0);
            player2Pos = player2Spawn.transform;
            Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Created Player2Spawn at (10, 0, 0)");
        }
    }

    internal IEnumerator SpawnPlayer(NetworkRunner runner)
    {
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Spawning Player for LocalPlayer {runner.LocalPlayer}");

        if (player1Pos == null || player2Pos == null)
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player1Pos or Player2Pos is not assigned!");
            IFrameBridge.Instance.PostMatchAbort("Game setup failed", "Spawn positions not set", "1014");
            yield break;
        }

        yield return new WaitUntil(() => runner != null && runner.IsRunning);

        if (FindObjectsOfType<HelixTowerRotation>().Any(p => p.Object != null && p.Object.InputAuthority == runner.LocalPlayer))
        {
            Debug.LogWarning($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player already spawned for this client!");
            yield break;
        }

        string playerId;
        Vector3 spawnPosition;
        int playerCount = runner.ActivePlayers.Count();

        if (playerCount <= 1)
        {
            playerId = "Player1";
            spawnPosition = player1Pos.position;
        }
        else
        {
            playerId = "Player2";
            spawnPosition = player2Pos.position;
        }

        NetworkObject playerObject = runner.Spawn(playerPrefab, spawnPosition, Quaternion.identity, runner.LocalPlayer);
        if (playerObject == null)
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Failed to spawn {playerId} NetworkObject!");
            IFrameBridge.Instance.PostMatchAbort("Game setup failed", "Spawn failed", "1016");
            yield break;
        }

        // Set the GameManager's PlayerId
        GameManager gm = playerObject.GetComponentInChildren<GameManager>();
        if (gm != null)
        {
            gm.PlayerId = playerId;
        }
        else
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] GameManager component not found in {playerId} prefab!");
        }

        HelixTowerRotation helix = playerObject.transform.Find("RINGS")?.GetComponent<HelixTowerRotation>();
        if (helix == null)
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] HelixTowerRotation component not found in {playerId} prefab on RINGS!");
            IFrameBridge.Instance.PostMatchAbort("Game setup failed", "HelixTowerRotation not found", "1013");
            runner.Despawn(playerObject);
            yield break;
        }
        else
        {
            Debug.Log("First time");
        }

        helix.PlayerId = playerId;
        helix.isPlayer2 = playerId == "Player2";
        helix.enabled = false;

        LocalPlayerId = playerId;
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Set LocalPlayerId to {LocalPlayerId} for runner.LocalPlayer {runner.LocalPlayer}");

        GameObject playerBall = playerObject.transform.Find("BALL")?.gameObject;
        GameObject playerCameraObj = playerObject.transform.Find("Camera")?.gameObject;
        GameObject cylinder1 = playerObject.transform.Find("Cylinder1")?.gameObject;
        GameObject cylinder2 = playerObject.transform.Find("Cylinder2")?.gameObject;
        GameObject rings = playerObject.transform.Find("RINGS")?.gameObject;

        if (playerBall == null || playerCameraObj == null || cylinder1 == null || cylinder2 == null || rings == null)
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] {playerId} missing components: BALL={playerBall}, Camera={playerCameraObj}, Cylinder1={cylinder1}, Cylinder2={cylinder2}, RINGS={rings}");
            IFrameBridge.Instance.PostMatchAbort("Game setup failed", $"{playerId} components missing", "1014");
            runner.Despawn(playerObject);
            yield break;
        }

        // Ensure rings are properly tagged and under the NetworkObject hierarchy
        foreach (Transform child in rings.transform)
        {
            child.gameObject.tag = playerId;
        }

        playerObject.gameObject.tag = playerId;
        playerBall.tag = playerId;
        playerCameraObj.tag = playerId;
        cylinder1.tag = playerId;
        cylinder2.tag = playerId;
        rings.tag = playerId;

        Camera playerCamera = playerCameraObj.GetComponent<Camera>();
        if (playerCamera == null)
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Camera component not found in {playerId} prefab!");
            IFrameBridge.Instance.PostMatchAbort("Game setup failed", "Camera not found", "1015");
            runner.Despawn(playerObject);
            yield break;
        }
        playerCamera.rect = playerId == "Player1" ? new Rect(0, 0, 0.5f, 1) : new Rect(0.5f, 0, 0.5f, 1);
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Initial camera setup for {playerId}: Rect={playerCamera.rect}, Camera Tag={playerCameraObj.tag}");

        // yield return new WaitForSeconds(0.5f);
        helix.RPC_SetPlayerProperties(playerId);

        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Spawned {playerId} at {spawnPosition}, PlayerId: {helix.PlayerId}, isPlayer2: {helix.isPlayer2}, tags: Root={playerObject.tag}, BALL={playerBall.tag}, Camera={playerCameraObj.tag}, InputAuthority: {playerObject.InputAuthority}");

        StartCoroutine(WaitForPlayers());
    }

    void Start()
    {
        Time.timeScale = 1f;

        if (Connector.Instance != null)
        {
            StartCoroutine(SpawnPlayer(Connector.Instance.NetworkRunner));
        }
        else
        {
            StartGame(true);
        }
    }

    public void StartGameUI()
    {
        if (scoreboardPanel != null) scoreboardPanel.SetActive(true);
        if (scoreText != null) scoreText.gameObject.SetActive(true);
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Game UI started");
    }

    public void StartGame(bool isOnePlayer)
    {
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Starting {(isOnePlayer ? "single-player" : "multiplayer")} game");
        isOnePlayerMode = isOnePlayer;
        if (scoreText != null) scoreText.gameObject.SetActive(true);

        if (isOnePlayer)
        {
            foreach (var helix in FindObjectsOfType<HelixTowerRotation>())
            {
                Destroy(helix.gameObject);
            }

            SpawnLocalPlayers();
            HelixTowerRotation[] helixes = FindObjectsOfType<HelixTowerRotation>();
            if (helixes.Length < 2)
            {
                Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Only {helixes.Length} helixes found!");
                IFrameBridge.Instance.PostMatchAbort("Game setup failed", "Insufficient helixes", "1011");
                return;
            }
            player1Helix = helixes.FirstOrDefault(p => p.PlayerId == "Player1");
            player2Helix = helixes.FirstOrDefault(p => p.PlayerId == "Player2");
            if (player1Helix == null || player2Helix == null)
            {
                Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Failed to find Player1 or Player2 helix in single-player mode!");
                IFrameBridge.Instance.PostMatchAbort("Game setup failed", "Helixes not found", "1011");
                return;
            }

            player1Helix.gameObject.SetActive(true);
            player2Helix.gameObject.SetActive(true);
            player1Helix.enabled = true;
            player2Helix.enabled = true;
            player2Helix.isAI = true;

            isGameStarted = true;
            Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Game started in single-player mode");

            ConfigureCameras();
            StartGameUI();
            UpdateScoreUI();
            player1Helix.transform.position = new Vector3(-10, 0, 0);
            player2Helix.transform.position = new Vector3(10, 0, 0);
        }
    }

    public void SpawnLocalPlayers()
    {
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Spawning local players for single-player mode");
        var prefab = Resources.Load<GameObject>("PlayerPrefab");
        if (prefab == null)
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] PlayerPrefab not found in Resources!");
            IFrameBridge.Instance.PostMatchAbort("Game setup failed", "PlayerPrefab not found", "1012");
            return;
        }

        GameObject player1Obj = Instantiate(prefab, new Vector3(-10, 0, 0), Quaternion.identity);
        player1Obj.tag = "Player1";
        GameObject player1Ball = player1Obj.transform.Find("BALL")?.gameObject;
        GameObject player1CameraObj = player1Obj.transform.Find("Camera")?.gameObject;
        GameObject player1Cylinder1 = player1Obj.transform.Find("Cylinder1")?.gameObject;
        GameObject player1Cylinder2 = player1Obj.transform.Find("Cylinder2")?.gameObject;
        GameObject player1Rings = player1Obj.transform.Find("RINGS")?.gameObject;

        if (player1Ball == null || player1CameraObj == null || player1Cylinder1 == null || player1Cylinder2 == null || player1Rings == null)
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player1 missing components!");
            IFrameBridge.Instance.PostMatchAbort("Game setup failed", "Player1 components missing", "1014");
            Destroy(player1Obj);
            return;
        }

        player1Ball.tag = "Player1";
        player1CameraObj.tag = "Player1";
        player1Cylinder1.tag = "Player1";
        player1Cylinder2.tag = "Player1";
        player1Rings.tag = "Player1";

        foreach (Transform child in player1Rings.transform)
        {
            child.gameObject.tag = "Player1";
        }

        HelixTowerRotation player1Ctrl = player1Rings.GetComponent<HelixTowerRotation>();
        player1Ctrl.PlayerId = "Player1";
        player1Ctrl.isPlayer2 = false;
        player1Ctrl.RandomRotation();

        GameObject player2Obj = Instantiate(prefab, new Vector3(10, 0, 0), Quaternion.identity);
        player2Obj.tag = "Player2";
        GameObject player2Ball = player2Obj.transform.Find("BALL")?.gameObject;
        GameObject player2CameraObj = player2Obj.transform.Find("Camera")?.gameObject;
        GameObject player2Cylinder1 = player2Obj.transform.Find("Cylinder1")?.gameObject;
        GameObject player2Cylinder2 = player2Obj.transform.Find("Cylinder2")?.gameObject;
        GameObject player2Rings = player2Obj.transform.Find("RINGS")?.gameObject;

        if (player2Ball == null || player2CameraObj == null || player2Cylinder1 == null || player2Cylinder2 == null || player2Rings == null)
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player2 missing components!");
            IFrameBridge.Instance.PostMatchAbort("Game setup failed", "Player2 components missing", "1014");
            Destroy(player1Obj);
            Destroy(player2Obj);
            return;
        }

        player2Ball.tag = "Player2";
        player2CameraObj.tag = "Player2";
        player2Cylinder1.tag = "Player2";
        player2Cylinder2.tag = "Player2";
        player2Rings.tag = "Player2";

        foreach (Transform child in player2Rings.transform)
        {
            child.gameObject.tag = "Player2";
        }

        HelixTowerRotation player2Ctrl = player2Rings.GetComponent<HelixTowerRotation>();
        player2Ctrl.PlayerId = "Player2";
        player2Ctrl.isPlayer2 = true;
        player2Ctrl.isAI = true;
        player2Ctrl.RandomRotation();

        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Spawned Player1 at {player1Obj.transform.position}, PlayerId: {player1Ctrl.PlayerId}, tags: Root={player1Obj.tag}, BALL={player1Ball.tag}, Camera={player1CameraObj.tag}");
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Spawned Player2 at {player2Obj.transform.position}, PlayerId: {player2Ctrl.PlayerId}, isAI: {player2Ctrl.isAI}, tags: Root={player2Obj.tag}, BALL={player2Ball.tag}, Camera={player2CameraObj.tag}");

        LocalPlayerId = "Player1";
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Set LocalPlayerId to {LocalPlayerId} for single-player mode");
    }

    public void StartMultiplayerGame()
    {
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Starting multiplayer game");

        HelixTowerRotation[] helixes = FindObjectsOfType<HelixTowerRotation>();
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Found {helixes.Length} helixes");
        foreach (var h in helixes)
        {
            var ball = h.transform.parent?.Find("BALL")?.gameObject;
            Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Helix for {h.PlayerId}, Position: {h.transform.position}, Tag: {h.gameObject.tag}, Ball Tag: {ball?.tag}, InputAuthority: {(h.Object != null ? h.Object.InputAuthority.ToString() : "null")}");
        }

        player1Helix = helixes.FirstOrDefault(p => p.PlayerId == "Player1");
        player2Helix = helixes.FirstOrDefault(p => p.PlayerId == "Player2");

        if (player1Helix == null || player2Helix == null)
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Failed to find Player1 or Player2 helix! P1: {player1Helix}, P2: {player2Helix}");
            IFrameBridge.Instance.PostMatchAbort("Game setup failed", "Helixes not found", "1011");
            return;
        }

        player1Helix.transform.position = player1Pos.position;
        player2Helix.transform.position = player2Pos.position;

        player1Helix.enabled = true;
        player2Helix.enabled = true;
        isGameStarted = true;
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Game started in multiplayer mode");

        NetworkRunner runner = Connector.Instance.NetworkRunner;
        if (runner.IsServer)
        {
            runner.SessionInfo.IsOpen = false;
            Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Session closed by host");
        }

        StartGameUI();
        UpdateScoreUI();

        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Multiplayer game started successfully");
    }

    private void ConfigureCameras()
    {
        if (player1Helix != null)
        {
            Camera player1Camera = player1Helix.transform.parent?.Find("Camera")?.GetComponent<Camera>();
            if (player1Camera != null)
            {
                player1Camera.rect = new Rect(0, 0, 0.5f, 1);
                Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Configured camera for Player1: Rect={player1Camera.rect}, Camera Tag={player1Camera.gameObject.tag}, InputAuthority={player1Helix.Object?.InputAuthority}");
            }
            else
            {
                Debug.LogWarning($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player1 camera not found!");
            }
        }

        if (player2Helix != null)
        {
            Camera player2Camera = player2Helix.transform.parent?.Find("Camera")?.GetComponent<Camera>();
            if (player2Camera != null)
            {
                player2Camera.rect = new Rect(0.5f, 0, 0.5f, 1);
                Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Configured camera for Player2: Rect={player2Camera.rect}, Camera Tag={player2Camera.gameObject.tag}, InputAuthority={player2Helix.Object?.InputAuthority}");
            }
            else
            {
                Debug.LogWarning($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player2 camera not found!");
            }
        }
    }

    private IEnumerator WaitForPlayers()
    {
        float timeout = 200f;
        float elapsed = 0f;
        while (elapsed < timeout)
        {
            HelixTowerRotation[] helixes = FindObjectsOfType<HelixTowerRotation>();
            var player1 = helixes.FirstOrDefault(p => p.PlayerId == "Player1");
            var player2 = helixes.FirstOrDefault(p => p.PlayerId == "Player2");

            if (player1 != null && player1.gameObject.tag == "Untagged")
            {
                Debug.LogWarning($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player1 tags are Untagged, attempting to set locally");
                player1.SetTagsLocally("Player1");
            }
            if (player2 != null && player2.gameObject.tag == "Untagged")
            {
                Debug.LogWarning($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player2 tags are Untagged, attempting to set locally");
                player2.SetTagsLocally("Player2");
            }

            Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Waiting for 2 helixes... Found {helixes.Length}, P1: {(player1 != null ? $"Found (PlayerId={player1.PlayerId}, tag={player1.gameObject.tag}, Ball Tag={player1.transform.parent?.Find("BALL")?.tag}, InputAuthority={(player1.Object != null ? player1.Object.InputAuthority.ToString() : "null")})" : "null")}, P2: {(player2 != null ? $"Found (PlayerId={player2.PlayerId}, tag={player2.gameObject.tag}, Ball Tag={player2.transform.parent?.Find("BALL")?.tag}, InputAuthority={(player2.Object != null ? player2.Object.InputAuthority.ToString() : "null")})" : "null")}");

            if (player1 != null && player2 != null && player1.gameObject.tag == "Player1" && player2.gameObject.tag == "Player2")
            {
                player1Helix = player1;
                player2Helix = player2;
                ConfigureCameras();
                StartMultiplayerGame();
                yield break;
            }

            yield return new WaitForSeconds(0.5f);
            elapsed += 0.5f;
        }

        Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Timed out waiting for 2 helixes with correct tags!");
        IFrameBridge.Instance.PostMatchAbort("Game setup failed", "Timed out waiting for helixes", "1011");
    }

    public void IncrementPlayer1Score()
    {
        if (!isGameStarted || isGameEnded) return;

        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player 1 scored");
        player1Score++;
        UpdateScoreUI();
        if (player1Score >= scoreToWin)
        {
            isGameEnded = true;
            EndGame("Player1");
        }
    }

    public void IncrementPlayer2Score()
    {
        if (!isGameStarted || isGameEnded) return;

        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Player 2 scored");
        player2Score++;
        UpdateScoreUI();
        if (player2Score >= scoreToWin)
        {
            isGameEnded = true;
            EndGame("Player2");
        }
    }

    void UpdateScoreUI()
    {
        if (scoreText != null)
        {
            scoreText.text = $"P1: {player1Score} | P2: {player2Score}";
            Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] Updated score UI: P1={player1Score}, P2={player2Score}");
        }
        else
        {
            Debug.LogError($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] scoreText is not assigned!");
        }
    }

    void EndGame(string winner)
    {
        Debug.Log($"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] [GameplayManager] {winner} Wins!");
        if (isOnePlayerMode)
        {
            if (player1Helix != null) player1Helix.enabled = false;
            if (player2Helix != null) player2Helix.enabled = false;
        }
        else
        {
            if (player1Helix != null) player1Helix.enabled = false;
            if (player2Helix != null) player2Helix.enabled = false;
        }

        if (scoreboardPanel != null) scoreboardPanel.SetActive(false);
        if (scoreText != null) scoreText.gameObject.SetActive(false);

        string outcome = isOnePlayerMode 
            ? (winner == "Player1" ? "won" : "lost")
            : (winner == "Player1" && IFrameBridge.PlayerId == "Player1") || 
              (winner == "Player2" && IFrameBridge.PlayerId == "Player2") ? "won" : "lost";
        int score = winner == "Player1" ? player1Score : player2Score;
        IFrameBridge.Instance.PostMatchResult(outcome, score);
    }
}